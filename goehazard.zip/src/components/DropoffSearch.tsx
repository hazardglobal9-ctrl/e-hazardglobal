import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, MapPin, Navigation, Search } from "lucide-react";
import { useLang } from "@/lib/i18n";
import { findDropoff, type DropoffPlace } from "@/lib/ai.functions";

export function mapsUrl(city: string) {
  return "https://www.google.com/maps/search/" + encodeURIComponent(`e-waste drop off ${city.trim()}`);
}

function placeUrl(p: DropoffPlace) {
  return "https://www.google.com/maps/search/?api=1&query=" + (p.query ? encodeURIComponent(p.query) : `${p.lat},${p.lon}`);
}

export function DropoffSearch() {
  const { t, lang } = useLang();
  const find = useServerFn(findDropoff);
  const [city, setCity] = useState("");
  const [searched, setSearched] = useState("");
  const [loading, setLoading] = useState(false);
  const [places, setPlaces] = useState<DropoffPlace[] | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const c = city.trim();
    if (!c || loading) return;
    setLoading(true);
    setSearched(c);
    try {
      const r = await find({ data: { city: c, lang } });
      setPlaces(r.places);
    } catch (err) {
      console.error(err);
      setPlaces([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="dropoff" className="rounded-3xl bg-rust p-5 shadow-soft">
      <h2 className="mb-3 text-center text-lg font-semibold text-primary-foreground">{t("dropTitle")}</h2>
      <form onSubmit={onSubmit} className="flex items-center gap-2 rounded-full bg-cream py-1.5 pl-4 pr-1.5">
        <Search className="h-5 w-5 shrink-0 text-ink" />
        <input
          value={city}
          onChange={(e) => setCity(e.target.value)}
          placeholder={t("dropPlaceholder")}
          className="min-w-0 flex-1 bg-transparent text-sm text-ink outline-none placeholder:text-muted-foreground"
        />
        <button type="submit" disabled={loading} className="rounded-full bg-rust px-5 py-2 text-sm font-bold text-primary-foreground disabled:opacity-70">
          {t("search")}
        </button>
      </form>

      {loading && (
        <p className="mt-3 flex items-center justify-center gap-2 text-sm text-primary-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> {t("dropSearching")}
        </p>
      )}

      {!loading && places && (
        <div className="mt-3 space-y-2">
          {places.length > 0 ? (
            <>
              <p className="text-xs font-semibold text-primary-foreground">{t("dropPick")}</p>
              <ul className="space-y-2">
                {places.map((p, i) => (
                  <li key={i}>
                    <a
                      href={placeUrl(p)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 rounded-2xl bg-cream p-3 text-ink transition-transform active:scale-[0.98]"
                    >
                      <MapPin className="h-5 w-5 shrink-0 text-primary" />
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm font-bold">{p.name}</span>
                        <span className="block text-xs text-muted-foreground">{p.address}</span>
                        <span className="block text-[0.7rem] font-semibold text-primary">{p.type}{p.km >= 0 ? ` · ${p.km} km` : ""}</span>
                      </span>
                      <Navigation className="h-4 w-4 shrink-0 text-primary" />
                    </a>
                  </li>
                ))}
              </ul>
            </>
          ) : (
            <p className="text-center text-sm text-primary-foreground">{t("dropEmpty")}</p>
          )}
          <a href={mapsUrl(searched)} target="_blank" rel="noopener noreferrer" className="block text-center text-xs font-bold text-primary-foreground underline">
            {t("openMaps")}
          </a>
        </div>
      )}

      {!places && !loading && <p className="mt-2 text-center text-xs text-primary-foreground/90">{t("dropHint")}</p>}
    </section>
  );
}
