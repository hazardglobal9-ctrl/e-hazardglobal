import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import type { ReactNode } from "react";
import { LangToggle } from "./LangToggle";
import { useLang } from "@/lib/i18n";

export function AppShell({ children, back }: { children: ReactNode; back?: boolean }) {
  const { t } = useLang();
  return (
    <div className="mx-auto min-h-screen w-full max-w-md px-5 pb-10 pt-4">
      <div className="mb-2 flex items-center justify-between">
        {back ? (
          <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm font-bold text-ink">
            <ArrowLeft className="h-4 w-4" /> {t("back")}
          </Link>
        ) : (
          <span />
        )}
        <LangToggle />
      </div>
      {children}
    </div>
  );
}
