import a from "@/assets/mascot-a.png.asset.json";
import b from "@/assets/mascot-b.png.asset.json";
import { cn } from "@/lib/utils";
import { useLang } from "@/lib/i18n";

export function Mascot({ pose, className }: { pose: "a" | "b"; className?: string }) {
  const { t } = useLang();
  return (
    <div className={cn("flex max-w-full shrink-0 items-center justify-center p-1", className)}>
      <img
        src={pose === "a" ? a.url : b.url}
        alt={t("mascotAlt")}
        className="float-slow h-auto w-full max-w-full select-none object-contain drop-shadow-xl"
        draggable={false}
      />
    </div>
  );
}
