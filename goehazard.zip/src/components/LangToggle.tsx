import { useLang } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export function LangToggle({ className }: { className?: string }) {
  const { lang, setLang } = useLang();
  return (
    <div className={cn("inline-flex rounded-full bg-rust p-0.5 text-xs font-bold shadow-soft", className)}>
      {(["id", "en"] as const).map((l) => (
        <button
          key={l}
          onClick={() => setLang(l)}
          aria-pressed={lang === l}
          className={cn(
            "rounded-full px-2.5 py-1 transition-colors",
            lang === l ? "bg-cream text-rust" : "text-primary-foreground",
          )}
        >
          {l === "id" ? "🇮🇩 ID" : "🇬🇧 EN"}
        </button>
      ))}
    </div>
  );
}
