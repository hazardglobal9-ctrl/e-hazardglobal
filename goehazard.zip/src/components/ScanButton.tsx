import { useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Camera, Image as ImageIcon } from "lucide-react";
import { analyzeImage } from "@/lib/ai.functions";
import { setScan } from "@/lib/scan-store";
import { useLang } from "@/lib/i18n";

async function toDataUrl(file: File): Promise<string> {
  const url = URL.createObjectURL(file);
  const img = new Image();
  await new Promise((r, j) => ((img.onload = r), (img.onerror = j), (img.src = url)));
  const max = 1280;
  const s = Math.min(1, max / Math.max(img.width, img.height));
  const c = document.createElement("canvas");
  c.width = Math.round(img.width * s);
  c.height = Math.round(img.height * s);
  c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
  URL.revokeObjectURL(url);
  return c.toDataURL("image/jpeg", 0.85);
}

export function useScanner() {
  const camRef = useRef<HTMLInputElement>(null);
  const galRef = useRef<HTMLInputElement>(null);
  const [picking, setPicking] = useState(false);
  const navigate = useNavigate();
  const analyze = useServerFn(analyzeImage);
  const { lang, t } = useLang();

  const onFile = async (f?: File) => {
    if (!f) return;
    const image = await toDataUrl(f);
    setScan({ image, results: {}, loading: true, translating: false, error: null });
    navigate({ to: "/hasil" });
    try {
      const r = await analyze({ data: { image, lang } });
      if (r.ok) setScan({ results: { [lang]: r.result }, loading: false });
      else setScan({ error: t(r.error === "credits" ? "errCredits" : r.error === "rate" ? "errRate" : "analyzeFail"), loading: false });
    } catch (e) {
      console.error(e);
      setScan({ error: t("genericError"), loading: false });
    }
  };

  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFile(e.target.files?.[0]);
    e.target.value = "";
  };

  const choose = (ref: React.RefObject<HTMLInputElement | null>) => () => {
    setPicking(false);
    ref.current?.click();
  };

  const inputs = (
    <>
      <input ref={camRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={onChange} />
      <input ref={galRef} type="file" accept="image/*" className="hidden" onChange={onChange} />
    </>
  );

  const picker = picking ? (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-ink/50 p-4 backdrop-blur-sm sm:items-center"
      onClick={() => setPicking(false)}
    >
      <div
        className="w-full max-w-xs rounded-3xl bg-card p-5 shadow-cta"
        onClick={(e) => e.stopPropagation()}
      >
        <p className="mb-4 text-center font-display text-lg font-semibold text-ink">{t("pickSource")}</p>
        <div className="space-y-3">
          <button
            onClick={choose(camRef)}
            className="flex w-full items-center gap-3 rounded-2xl bg-primary px-4 py-3 font-semibold text-primary-foreground transition-transform active:scale-95"
          >
            <Camera className="h-6 w-6" />
            {t("takePhoto")}
          </button>
          <button
            onClick={choose(galRef)}
            className="flex w-full items-center gap-3 rounded-2xl bg-edu px-4 py-3 font-semibold text-edu-foreground transition-transform active:scale-95"
          >
            <ImageIcon className="h-6 w-6" />
            {t("fromGallery")}
          </button>
        </div>
      </div>
    </div>
  ) : null;

  return { open: () => setPicking(true), picker, inputs };
}

export function ScanCard() {
  const { t } = useLang();
  const { open, picker, inputs } = useScanner();
  return (
    <section className="bg-detect mx-auto w-4/5 rounded-3xl p-5 text-center shadow-cta">
      <h2 className="text-2xl font-bold text-primary-foreground">{t("detectTitle")}</h2>
      <p className="mx-auto mt-1 max-w-xs text-xs font-semibold text-primary-foreground">{t("detectSub")}</p>
      <button onClick={open} className="bg-cream mt-4 flex w-full flex-col items-center rounded-3xl px-4 py-6 text-primary transition-transform active:scale-95">
        <Camera className="h-20 w-20" strokeWidth={1.4} />
        <span className="mt-2 font-display text-lg font-bold">{t("detectBtn")}</span>
      </button>
      {inputs}
      {picker}
    </section>
  );
}
