import { createFileRoute, Link } from "@tanstack/react-router";
import { LangToggle } from "@/components/LangToggle";
import { Mascot } from "@/components/Mascot";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "E-Hazard — Teknologi di tanganmu, Informasi dalam 1 scan" },
      { name: "description", content: "Selamat datang di E-Hazard: deteksi limbah elektronik dan tingkat bahayanya dengan AI." },
      { property: "og:title", content: "E-Hazard Tracker" },
      { property: "og:description", content: "Teknologi di tanganmu, Informasi dalam 1 scan." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Welcome,
});

function Welcome() {
  const { t } = useLang();
  return (
    <main className="relative mx-auto flex min-h-screen max-w-md flex-col items-center px-6 pb-10 pt-4 text-center">
      <LangToggle className="self-end" />
      <Mascot pose="a" className="mt-2 w-[min(13rem,52vw,30svh)] py-3 sm:w-56" />
      <h1 className="title-pop mt-1 text-[2rem] leading-tight sm:text-4xl">{t("hello")}</h1>
      <p className="mt-2 max-w-xs text-sm font-bold text-rust">{t("welcomeSub")}</p>
      <p className="bg-tagline mt-6 w-full rounded-3xl px-5 py-6 font-display text-lg sm:text-xl font-semibold text-primary-foreground shadow-soft">
        “{t("tagline")}”
      </p>
      <Link
        to="/dashboard"
        className="mt-6 w-4/5 rounded-3xl bg-rust py-4 font-display text-3xl font-bold text-primary-foreground shadow-cta transition-transform hover:scale-[1.02] active:scale-95"
      >
        {t("enter")}
      </Link>
    </main>
  );
}
