import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, Brain } from "lucide-react";
import { LangToggle } from "@/components/LangToggle";
import { Mascot } from "@/components/Mascot";
import { DropoffSearch } from "@/components/DropoffSearch";
import { ScanCard } from "@/components/ScanButton";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — E-Hazard" },
      { name: "description", content: "Deteksi e-waste dengan kamera, kuis, edukasi, dan cari titik drop-off." },
      { property: "og:title", content: "Dashboard E-Hazard" },
      { property: "og:description", content: "Pusat fitur E-Hazard: kamera, kuis, edukasi, drop-off." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { t } = useLang();
  return (
    <main className="relative mx-auto min-h-screen w-full max-w-md space-y-5 px-5 pb-10 pt-4">
      <LangToggle className="absolute right-5 top-4" />
      <h1 className="title-pop px-2 pt-10 text-center text-[1.4rem] sm:text-2xl leading-tight">{t("dashHello")}</h1>

      <div className="grid grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)] items-center gap-2">
        <Link to="/quiz" className="flex flex-col items-center bg-tile rounded-3xl px-2 py-8 text-center text-primary-foreground shadow-soft transition-transform hover:scale-105">
          <Brain className="h-8 w-8" />
          <span className="mt-1 font-display text-lg font-semibold">{t("quiz")}</span>
          <span className="whitespace-nowrap text-[0.7rem] font-semibold">{t("quizDesc")}</span>
        </Link>
        <Mascot pose="b" className="w-24 sm:w-32" />
        <Link to="/edu" className="flex flex-col items-center bg-tile rounded-3xl px-2 py-8 text-center text-primary-foreground shadow-soft transition-transform hover:scale-105">
          <BookOpen className="h-8 w-8" />
          <span className="mt-1 font-display text-lg font-semibold">{t("edu")}</span>
          <span className="whitespace-nowrap text-[0.7rem] font-semibold">{t("eduDesc")}</span>
        </Link>
      </div>

      <DropoffSearch />
      <ScanCard />
    </main>
  );
}
