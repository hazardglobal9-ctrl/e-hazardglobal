import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Mascot } from "@/components/Mascot";
import { generateQuiz, type QuizQuestion } from "@/lib/ai.functions";
import { AppShell } from "@/components/AppShell";
import { quiz as staticQuiz } from "@/lib/content";
import { useLang } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/quiz")({
  head: () => ({
    meta: [
      { title: "Kuis E-Waste — E-Hazard" },
      { name: "description", content: "Uji pengetahuanmu tentang limbah elektronik lewat kuis singkat." },
      { property: "og:title", content: "Kuis E-Waste" },
      { property: "og:description", content: "8 soal seru seputar e-waste." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Quiz,
});

function Quiz() {
  const { t, lang } = useLang();
  const [i, setI] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [quiz, setQuiz] = useState<QuizQuestion[]>(staticQuiz);
  const [loading, setLoading] = useState(true);
  const load = useCallback(async () => {
    setLoading(true);
    setI(0);
    setScore(0);
    setPicked(null);
    try {
      const r = await generateQuiz();
      setQuiz(r.ok ? r.questions : staticQuiz);
    } catch {
      setQuiz(staticQuiz);
    }
    setLoading(false);
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  const done = i >= quiz.length;

  if (loading)
    return (
      <AppShell back>
        <div className="mt-10 flex flex-col items-center gap-4 text-center">
          <Mascot pose="a" className="w-40" />
          <p className="font-display text-lg font-semibold text-ink">{t("quizLoading")}</p>
        </div>
      </AppShell>
    );

  if (done)
    return (
      <AppShell back>
        <div className="mt-10 rounded-3xl bg-quiz p-8 text-center text-quiz-foreground">
          <p className="font-semibold">{t("score")}</p>
          <p className="font-display text-6xl font-bold">
            {score}/{quiz.length}
          </p>
          <button
            onClick={() => void load()}
            className="mt-6 rounded-full bg-primary px-6 py-3 font-bold text-primary-foreground"
          >
            {t("retry")}
          </button>
        </div>
      </AppShell>
    );

  const q = quiz[i]!;
  return (
    <AppShell back>
      <h1 className="title-pop text-3xl">{t("quizTitle")}</h1>
      <p className="mt-1 text-sm font-semibold text-muted-foreground">
        {t("question")} {i + 1}/{quiz.length}
      </p>
      <div className="mt-4 rounded-3xl bg-quiz p-5 font-display text-lg font-semibold text-quiz-foreground">{q.q[lang]}</div>
      <div className="mt-4 space-y-2">
        {q.options.map((o, k) => (
          <button
            key={k}
            disabled={picked !== null}
            onClick={() => {
              setPicked(k);
              if (k === q.answer) setScore((s) => s + 1);
            }}
            className={cn(
              "w-full rounded-2xl bg-card p-4 text-left font-semibold text-ink transition",
              picked !== null && k === q.answer && "bg-edu text-edu-foreground",
              picked === k && k !== q.answer && "bg-primary text-primary-foreground",
            )}
          >
            {o[lang]}
          </button>
        ))}
      </div>
      {picked !== null && (
        <>
          <p className="mt-4 rounded-2xl bg-popover p-3 text-sm text-ink">{q.why[lang]}</p>
          <button
            onClick={() => (setI(i + 1), setPicked(null))}
            className="mt-4 w-full rounded-full bg-primary py-3 font-bold text-primary-foreground"
          >
            {i + 1 === quiz.length ? t("finish") : t("next")}
          </button>
        </>
      )}
    </AppShell>
  );
}
