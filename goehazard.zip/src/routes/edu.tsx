import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { eduModules } from "@/lib/content";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/edu")({
  head: () => ({
    meta: [
      { title: "Edukasi E-Waste — E-Hazard" },
      { name: "description", content: "Bahaya kimia B3, urban mining, regulasi & penanganan aman, serta fun facts e-waste." },
      { property: "og:title", content: "Edukasi E-Waste" },
      { property: "og:description", content: "Belajar tentang limbah elektronik bersama E-Hazard." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Edu,
});

function Edu() {
  const { t, lang } = useLang();
  return (
    <AppShell back>
      <h1 className="title-pop mb-4 text-3xl">{t("eduTitle")}</h1>
      <Accordion type="single" collapsible defaultValue="0" className="space-y-3">
        {eduModules.map((m, i) => (
          <AccordionItem key={i} value={String(i)} className="rounded-3xl border-0 bg-edu px-5 text-edu-foreground">
            <AccordionTrigger className="font-display text-lg font-semibold hover:no-underline">
              {m.emoji} {m.title[lang]}
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-3">
                {m.sections.map((sec, k) => (
                  <div key={k} className="rounded-2xl bg-background/80 p-4 text-ink">
                    <h3 className="mb-2 font-display text-base font-semibold">{sec.title[lang]}</h3>
                    <ul className="list-disc space-y-1.5 pl-5 text-sm leading-relaxed">
                      {sec.points.map((p, j) => (
                        <li key={j}>{p[lang]}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </AppShell>
  );
}
