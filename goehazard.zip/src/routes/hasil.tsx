import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { useServerFn } from "@tanstack/react-start";
import { BookOpen, Brain, Camera, CheckCircle2, MapPin, AlertTriangle } from "lucide-react";
import { translateResult } from "@/lib/ai.functions";
import { AppShell } from "@/components/AppShell";
import { Mascot } from "@/components/Mascot";
import { useScanner } from "@/components/ScanButton";
import { getScan, setScan, useScan } from "@/lib/scan-store";
import { useLang } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/hasil")({
  head: () => ({
    meta: [
      { title: "Hasil Analisis — E-Hazard" },
      { name: "description", content: "Hasil analisis AI: kategori e-waste, tingkat bahaya, kandungan, dan cara penanganan." },
      { property: "og:title", content: "Hasil Analisis E-Hazard" },
      { property: "og:description", content: "Tingkat bahaya dan cara penanganan limbah elektronik." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Hasil,
});

function Hasil() {
  const { t, level, lang } = useLang();
  const { image, results, loading, translating, error } = useScan();
  const scanner = useScanner();
  const translate = useServerFn(translateResult);
  const result = results[lang] ?? null;

  useEffect(() => {
    if (loading || results[lang]) return;
    const source = results.id ?? results.en;
    if (!source) return;
    let cancelled = false;
    setScan({ translating: true, error: null });
    translate({ data: { result: source, lang } })
      .then((r) => {
        if (cancelled) return;
        if (r.ok) setScan({ results: { ...getScan().results, [lang]: r.result }, translating: false });
        else setScan({ translating: false, error: t("translateFail") });
      })
      .catch(() => !cancelled && setScan({ translating: false, error: t("translateFail") }));
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lang, loading, results]);

  const barColor =
    result?.hazard_level === "high" ? "bg-primary" : result?.hazard_level === "none" ? "bg-edu" : "bg-quiz";

  return (
    <AppShell back>
      <h1 className="title-pop mb-4 text-3xl">{t("resultTitle")}</h1>
      {image && <img src={image} alt="" className="mb-4 max-h-64 w-full rounded-3xl object-cover shadow-soft" />}

      {translating && !loading && (
        <p className="mb-3 animate-pulse rounded-2xl bg-card/85 p-3 text-center font-semibold text-ink">{t("translating")}</p>
      )}
      {loading && (
        <div className="flex flex-col items-center rounded-3xl bg-card p-6">
          <Mascot pose="a" className="w-32" />
          <p className="mt-2 animate-pulse font-display text-lg font-semibold text-ink">{t("analyzing")}</p>
        </div>
      )}
      {!loading && error && <p className="rounded-2xl bg-card p-4 font-semibold text-primary">{error}</p>}
      {!loading && !image && !error && <p className="rounded-2xl bg-card p-4 text-ink">{t("noResult")}</p>}

      {result && !loading && (
        <div className="space-y-4">
          <div className="rounded-3xl bg-card/85 p-5 backdrop-blur-sm">
            <div
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-sm font-extrabold",
                result.is_ewaste ? "bg-primary text-primary-foreground" : "bg-edu text-edu-foreground",
              )}
            >
              {result.is_ewaste ? <AlertTriangle className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
              {result.is_ewaste ? t("isEwaste") : t("notEwaste")}
            </div>
            <h2 className="mt-2 text-2xl font-bold text-ink">{result.object_name}</h2>
            <p className="text-sm font-semibold text-muted-foreground">{result.category}</p>

            <div className="mt-4">
              <div className="flex justify-between text-sm font-bold text-ink">
                <span>
                  {t("hazard")}: {level(result.hazard_level)}
                </span>
                <span>{Math.round(result.hazard_percent)}%</span>
              </div>
              <div className="mt-1.5 h-3 overflow-hidden rounded-full bg-background">
                <div className={cn("h-full rounded-full transition-all", barColor)} style={{ width: `${Math.max(3, result.hazard_percent)}%` }} />
              </div>
            </div>
          </div>

          <Block title={t("description")}>
            <p className="text-sm leading-relaxed">{result.description}</p>
          </Block>

          {result.hazardous_materials.length > 0 && (
            <Block title={t("materials")}>
              <ul className="space-y-2">
                {result.hazardous_materials.map((m, i) => (
                  <li key={i} className="rounded-2xl bg-quiz/60 p-3 text-sm">
                    <b>{m.name}</b> — {m.effect}
                  </li>
                ))}
              </ul>
            </Block>
          )}

          <Block title={t("handling")}>
            <ol className="space-y-2">
              {result.handling_steps.map((s, i) => (
                <li key={i} className="flex gap-3 text-sm">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-edu text-xs font-bold text-edu-foreground">{i + 1}</span>
                  {s}
                </li>
              ))}
            </ol>
          </Block>
        </div>
      )}

      <h3 className="mb-2 mt-6 font-display text-lg font-semibold text-ink">{t("shortcuts")}</h3>
      <div className="grid grid-cols-4 gap-2">
        <button onClick={scanner.open} className="hub bg-primary text-primary-foreground">
          <Camera className="h-6 w-6" />
          {t("rescan")}
        </button>
        <Link to="/quiz" className="hub bg-quiz text-quiz-foreground">
          <Brain className="h-6 w-6" />
          {t("quiz")}
        </Link>
        <Link to="/edu" className="hub bg-edu text-edu-foreground">
          <BookOpen className="h-6 w-6" />
          {t("edu")}
        </Link>
        <Link to="/dashboard" hash="dropoff" className="hub bg-card text-ink">
          <MapPin className="h-6 w-6" />
          {t("dropoff")}
        </Link>
      </div>
      {scanner.inputs}
      {scanner.picker}
    </AppShell>
  );
}

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-3xl bg-popover/85 p-5 text-ink backdrop-blur-sm shadow-soft">
      <h3 className="mb-2 font-display text-lg font-semibold">{title}</h3>
      {children}
    </section>
  );
}
