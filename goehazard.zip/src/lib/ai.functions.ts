import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const analysisSchema = z.object({
  object_name: z.string(),
  is_ewaste: z.boolean(),
  category: z.string(),
  hazard_level: z.enum(["none", "low", "medium", "high"]),
  hazard_percent: z.number(),
  description: z.string(),
  hazardous_materials: z.array(z.object({ name: z.string(), effect: z.string() })),
  handling_steps: z.array(z.string()),
});
export type AnalysisResult = z.infer<typeof analysisSchema>;

async function runStructured<T>(schema: z.ZodType<T>, system: string, content: unknown[]): Promise<T> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new Error("AI belum dikonfigurasi.");
  const { createOpenAI } = await import("@ai-sdk/openai");
  const { streamText, Output } = await import("ai");
  let runId: string | undefined;
  let failCode: "credits" | "rate" | undefined;
  const provider = createOpenAI({
    baseURL: "https://ai.gateway.lovable.dev/v1",
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: async (input, init) => {
      const h = new Headers(init?.headers);
      if (runId) h.set("X-Lovable-AIG-Run-ID", runId);
      const res = await fetch(input, { ...init, headers: h });
      runId ??= res.headers.get("X-Lovable-AIG-Run-ID") ?? undefined;
      if (res.status === 429) { failCode = "rate"; throw new Error("rate"); }
      if (res.status === 402) { failCode = "credits"; throw new Error("credits"); }
      return res;
    },
  });
  const result = streamText({
    model: provider.responses("openai/gpt-6-astra"),
    system,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    messages: [{ role: "user", content: content as any }],
    output: Output.object({ schema }),
    maxRetries: 0,
    providerOptions: {
      openai: {
        forceReasoning: true,
        reasoningEffort: "low",
        reasoningSummary: "auto",
        store: false,
        include: ["reasoning.encrypted_content"],
      },
    },
  });
  try {
    return (await result.output) as T;
  } catch (e) {
    throw new Error(failCode ?? (e instanceof Error ? e.message : "generic"));
  }
}

export const analyzeImage = createServerFn({ method: "POST" })
  .inputValidator((d: { image: string; lang: "id" | "en" }) => {
    if (!d.image?.startsWith("data:image/")) throw new Error("Gambar tidak valid");
    if (d.image.length > 8_000_000) throw new Error("Gambar terlalu besar");
    return d;
  })
  .handler(async ({ data }) => {
    const [meta = "", b64 = ""] = data.image.split(",");
    const mediaType = meta.slice(5, meta.indexOf(";"));
    const language = data.lang === "id" ? "Bahasa Indonesia" : "English";
    try {
      const result = await runStructured(
        analysisSchema,
        `You are E-Hazard, an e-waste expert. Identify the main object in the photo and decide whether it is electronic waste (e-waste). If it is not e-waste (e.g. a person, food, plant), set is_ewaste false, hazard_level "none", hazard_percent 0, category explaining it is not e-waste, hazardous_materials empty, and handling_steps with brief proper disposal advice. If it is e-waste, give its e-waste category (e.g. IT & telecommunications, large household appliance, small appliance, batteries, lighting, consumer electronics), a hazard_level and hazard_percent (0-100), short description, hazardous chemical materials (lead, mercury, cadmium, lithium, brominated flame retardants, etc.) each with its health/environmental effect, and 4-6 safe handling/disposal steps. Respond entirely in ${language}.`,
        [
          { type: "text", text: "Analyze this item." },
          { type: "file", mediaType, data: b64 },
        ],
      );
      return { ok: true as const, result };
    } catch (e) {
      console.error(e);
      const m = e instanceof Error ? e.message : "";
      return { ok: false as const, error: m === "credits" || m === "rate" ? m : "generic" };
    }
  });


export const translateResult = createServerFn({ method: "POST" })
  .inputValidator((d: { result: AnalysisResult; lang: "id" | "en" }) => {
    if (!d?.result || (d.lang !== "id" && d.lang !== "en")) throw new Error("Invalid input");
    return d;
  })
  .handler(async ({ data }) => {
    const language = data.lang === "id" ? "Bahasa Indonesia" : "English";
    try {
      const result = await runStructured(
        analysisSchema,
        `Translate every text field of this e-waste analysis JSON into ${language}. Keep is_ewaste, hazard_level and hazard_percent unchanged, keep the same number and order of items, and keep chemical names accurate.`,
        [{ type: "text", text: JSON.stringify(data.result) }],
      );
      return { ok: true as const, result: { ...result, is_ewaste: data.result.is_ewaste, hazard_level: data.result.hazard_level, hazard_percent: data.result.hazard_percent } };
    } catch (e) {
      console.error(e);
      return { ok: false as const, error: "translate failed" };
    }
  });

export type DropoffPlace = { name: string; address: string; type: string; lat: number; lon: number; km: number; query?: string };
const dropCache = new Map<string, DropoffPlace[]>();
const UA = { "User-Agent": "E-Hazard-Tracker/1.0 (e-waste education app)" };

export const findDropoff = createServerFn({ method: "POST" })
  .inputValidator((d: { city: string; lang: "id" | "en" }) => {
    const city = String(d?.city ?? "").trim().slice(0, 80);
    if (!city) throw new Error("City required");
    return { city, lang: d.lang === "en" ? ("en" as const) : ("id" as const) };
  })
  .handler(async ({ data }) => {
    const key = `${data.city.toLowerCase()}|${data.lang}`;
    const hit = dropCache.get(key);
    if (hit) return { ok: true as const, places: hit };
    try {
      const g = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(data.city)}`,
        { headers: { ...UA, "Accept-Language": data.lang } },
      );
      if (!g.ok) throw new Error(`geocode ${g.status}`);
      const geo = (await g.json()) as Array<{ lat: string; lon: string }>;
      if (!geo[0]) return { ok: true as const, places: [] as DropoffPlace[] };
      const lat = Number(geo[0].lat), lon = Number(geo[0].lon);
      const tagRe = "^recycling:(electrical_items|electrical_appliances|batteries|mobile_phones|small_appliances|computers)$";
      const q = `[out:json][timeout:12];nwr[~"${tagRe}"~"^yes$"](around:20000,${lat},${lon});out center 40;`;
      const ask = async (host: string) => {
        const r = await fetch(`https://${host}/api/interpreter`, {
          method: "POST",
          headers: { ...UA, "Content-Type": "application/x-www-form-urlencoded" },
          body: "data=" + encodeURIComponent(q),
          signal: AbortSignal.timeout(14000),
        });
        if (!r.ok) throw new Error(`overpass ${r.status}`);
        return r.json();
      };
      let o: unknown = null;
      try {
        o = await Promise.any([ask("overpass-api.de"), ask("overpass.kumi.systems"), ask("overpass.private.coffee")]);
      } catch {
        o = null;
      }
      const fallback = (): DropoffPlace[] => {
        const en = data.lang === "en";
        const kinds = en
          ? [["E-waste collection point", "e-waste collection"], ["Electronics recycling center", "electronic recycling center"], ["Waste bank (Bank Sampah)", "bank sampah"], ["Phone/laptop brand service center", "service center handphone laptop"], ["Environment agency (DLH)", "Dinas Lingkungan Hidup"]]
          : [["Titik pengumpulan e-waste", "e-waste drop off"], ["Pusat daur ulang elektronik", "daur ulang elektronik"], ["Bank Sampah", "bank sampah"], ["Service center resmi HP/laptop", "service center handphone laptop"], ["Dinas Lingkungan Hidup (DLH)", "Dinas Lingkungan Hidup"]];
        const list = kinds as Array<[string, string]>;
        return list.map(([name, q]) => ({ name, address: data.city, type: en ? "Search in Google Maps" : "Cari di Google Maps", lat: 0, lon: 0, km: -1, query: `${q} ${data.city}` }));
      };
      if (!o) return { ok: true as const, places: fallback(), fallback: true };
      const els = ((o) as { elements: Array<{ lat?: number; lon?: number; center?: { lat: number; lon: number }; tags?: Record<string, string> }> }).elements;
      const R = (x: number) => (x * Math.PI) / 180;
      const dist = (a: number, b: number) => {
        const dl = R(a - lat), dn = R(b - lon);
        const h = Math.sin(dl / 2) ** 2 + Math.cos(R(lat)) * Math.cos(R(a)) * Math.sin(dn / 2) ** 2;
        return 6371 * 2 * Math.asin(Math.sqrt(h));
      };
      const en = data.lang === "en";
      const places: DropoffPlace[] = els
        .map((e) => {
          const t = e.tags ?? {};
          const pl = e.lat ?? e.center?.lat, pn = e.lon ?? e.center?.lon;
          if (pl == null || pn == null) return null;
          const addr = [t["addr:street"] && `${t["addr:street"]} ${t["addr:housenumber"] ?? ""}`.trim(), t["addr:suburb"] ?? t["addr:district"], t["addr:city"]].filter(Boolean).join(", ");
          const kinds = [t["recycling:batteries"] === "yes" && (en ? "batteries" : "baterai"), (t["recycling:electrical_items"] === "yes" || t["recycling:electrical_appliances"] === "yes" || t["recycling:small_appliances"] === "yes") && (en ? "electronics" : "elektronik"), t["recycling:mobile_phones"] === "yes" && (en ? "phones" : "HP")].filter(Boolean).join(", ");
          return {
            name: t["name"] ?? t["operator"] ?? (en ? "E-waste recycling point" : "Titik daur ulang e-waste"),
            address: addr || `${pl.toFixed(4)}, ${pn.toFixed(4)}`,
            type: kinds || (en ? "Recycling point" : "Titik daur ulang"),
            lat: pl, lon: pn, km: Math.round(dist(pl, pn) * 10) / 10,
          };
        })
        .filter((p): p is DropoffPlace => !!p)
        .sort((a, b) => a.km - b.km)
        .slice(0, 15);
      if (places.length === 0) return { ok: true as const, places: fallback(), fallback: true };
      dropCache.set(key, places);
      return { ok: true as const, places };
    } catch (e) {
      console.error(e);
      return { ok: false as const, places: [] as DropoffPlace[] };
    }
  });

const L = z.object({ id: z.string(), en: z.string() });
const quizSchema = z.object({
  questions: z.array(z.object({ q: L, options: z.array(L), answer: z.number(), why: L })),
});
export type QuizQuestion = z.infer<typeof quizSchema>["questions"][number];

export const generateQuiz = createServerFn({ method: "POST" }).handler(async () => {
  const { eduModules } = await import("./content");
  const material = eduModules
    .map((m) => `# ${m.title.id}\n` + m.sections.map((s) => `## ${s.title.id}\n` + s.points.map((p) => `- ${p.id}`).join("\n")).join("\n"))
    .join("\n\n");
  try {
    const out = await runStructured(
      quizSchema,
      `You create quizzes for Indonesian teenagers about e-waste. Using ONLY the provided learning material, write 8 NEW, varied multiple-choice questions covering all modules. Each question has exactly 4 options, "answer" is the 0-based index of the correct option (vary its position), and "why" is a one-sentence explanation. Every text field has both "id" (Bahasa Indonesia) and "en" (English). Keep questions short. Seed: ${Math.random().toString(36).slice(2)}`,
      [{ type: "text", text: material }],
    );
    const questions = out.questions.filter((q) => q.options.length === 4 && q.answer >= 0 && q.answer < 4);
    if (questions.length < 3) throw new Error("Soal tidak valid");
    return { ok: true as const, questions };
  } catch (e) {
    console.error(e);
    return { ok: false as const };
  }
});
