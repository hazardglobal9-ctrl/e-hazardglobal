import { useSyncExternalStore } from "react";
import type { AnalysisResult } from "./ai.functions";
import type { Lang } from "./i18n";

type State = {
  image: string | null;
  results: Partial<Record<Lang, AnalysisResult>>;
  loading: boolean;
  translating: boolean;
  error: string | null;
};
let state: State = { image: null, results: {}, loading: false, translating: false, error: null };
const subs = new Set<() => void>();

export function setScan(patch: Partial<State>) {
  state = { ...state, ...patch };
  subs.forEach((f) => f());
}
export function getScan() {
  return state;
}

export function useScan() {
  return useSyncExternalStore(
    (f) => {
      subs.add(f);
      return () => subs.delete(f);
    },
    () => state,
    () => state,
  );
}
