import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "id" | "en";

const dict = {
  hello: { id: "Halo, Sahabat Elzero", en: "Hello, Elzero Friends" },
  welcomeSub: {
    id: "Selamat datang di E-Hazard, asisten pintar pendeteksi limbah elektronik",
    en: "Welcome to E-Hazard, your smart electronic-waste detection assistant",
  },
  tagline: {
    id: "Teknologi di tanganmu, Informasi dalam 1 scan",
    en: "Technology in your hands, Information in 1 scan",
  },
  enter: { id: "Masuk", en: "Enter" },
  dashHello: { id: "Hai!, mau cek limbah apa hari ini?", en: "Hi!, what waste shall we check today?" },
  quiz: { id: "Quiz", en: "Quiz" },
  edu: { id: "Edu", en: "Edu" },
  quizDesc: { id: "Uji wawasanmu", en: "Test yourself" },
  eduDesc: { id: "Belajar e-waste", en: "Learn e-waste" },
  dropTitle: { id: "Cari Titik Drop-off", en: "Find Drop-off Points" },
  dropPlaceholder: { id: "Ketik nama kota, mis. Jakarta", en: "Type a city, e.g. Tokyo" },
  search: { id: "Cari", en: "Search" },
  mascotAlt: { id: "Maskot robot E-Hazard", en: "E-Hazard robot mascot" },
  genericError: { id: "Terjadi kesalahan, coba lagi.", en: "Something went wrong, please try again." },
  analyzeFail: { id: "Gagal menganalisis foto. Coba lagi.", en: "Failed to analyze the photo. Please try again." },
  dropHint: { id: "Pilih tempat dari daftar untuk melihat rute di Google Maps.", en: "Pick a place from the list to see directions in Google Maps." },
  errCredits: { id: "Layanan AI sedang tidak tersedia (kredit AI habis). Coba lagi nanti.", en: "The AI service is unavailable right now (AI credits used up). Please try later." },
  errRate: { id: "Terlalu banyak permintaan. Tunggu sebentar lalu coba lagi.", en: "Too many requests. Wait a moment and try again." },
  dropSearching: { id: "Mencari tempat…", en: "Searching places…" },
  dropEmpty: { id: "Tempat tidak ditemukan. Coba buka Google Maps.", en: "No places found. Try Google Maps." },
  dropPick: { id: "Pilih tempat yang ingin dikunjungi:", en: "Pick a place to visit:" },
  openMaps: { id: "Buka di Google Maps", en: "Open in Google Maps" },
  detectTitle: { id: "Deteksi E-Waste", en: "Detect E-Waste" },
  detectSub: {
    id: "Foto barangmu, Elzero akan menganalisis tingkat bahayanya.",
    en: "Snap your item and Elzero will analyze its hazard level.",
  },
  detectBtn: { id: "Klik untuk mendeteksi", en: "Click to detect" },
  pickSource: { id: "Pilih sumber foto", en: "Choose photo source" },
  takePhoto: { id: "Ambil Foto", en: "Take Photo" },
  fromGallery: { id: "Pilih dari Galeri", en: "Choose from Gallery" },
  translating: { id: "Menerjemahkan hasil…", en: "Translating result…" },
  translateFail: { id: "Gagal menerjemahkan hasil.", en: "Failed to translate the result." },
  analyzing: { id: "Sedang menganalisis…", en: "Analyzing…" },
  resultTitle: { id: "Hasil analisis:", en: "Analysis result:" },
  isEwaste: { id: "Termasuk E-Waste", en: "Is E-Waste" },
  notEwaste: { id: "Bukan E-Waste", en: "Not E-Waste" },
  hazard: { id: "Tingkat Bahaya", en: "Hazard Level" },
  description: { id: "Deskripsi", en: "Description" },
  materials: { id: "Kandungan Berbahaya", en: "Hazardous Content" },
  handling: { id: "Cara Penanganan & Solusi", en: "Handling & Solutions" },
  noResult: { id: "Belum ada foto yang dianalisis.", en: "No photo analyzed yet." },
  shortcuts: { id: "Menu Pintas", en: "Shortcuts" },
  rescan: { id: "Deteksi Ulang", en: "Scan Again" },
  dropoff: { id: "Cari Drop-off", en: "Drop-off" },
  back: { id: "Kembali", en: "Back" },
  score: { id: "Skor kamu", en: "Your score" },
  retry: { id: "Ulangi Kuis", en: "Retry Quiz" },
  next: { id: "Lanjut", en: "Next" },
  finish: { id: "Selesai", en: "Finish" },
  question: { id: "Soal", en: "Question" },
  eduTitle: { id: "Edukasi E-Waste", en: "E-Waste Education" },
  quizTitle: { id: "Kuis E-Waste", en: "E-Waste Quiz" },
  quizLoading: { id: "Elzero sedang menyiapkan soal baru…", en: "Elzero is preparing new questions…" },
  levels: { id: { low: "Rendah", medium: "Sedang", high: "Tinggi", none: "Aman" }, en: { low: "Low", medium: "Medium", high: "High", none: "Safe" } },
} as const;

type Key = Exclude<keyof typeof dict, "levels">;

const Ctx = createContext<{ lang: Lang; setLang: (l: Lang) => void }>({ lang: "id", setLang: () => {} });

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("id");
  useEffect(() => {
    const s = localStorage.getItem("ehz-lang");
    if (s === "id" || s === "en") setLangState(s);
  }, []);
  const setLang = (l: Lang) => {
    setLangState(l);
    localStorage.setItem("ehz-lang", l);
  };
  return <Ctx.Provider value={{ lang, setLang }}>{children}</Ctx.Provider>;
}

export function useLang() {
  const { lang, setLang } = useContext(Ctx);
  const t = (k: Key) => dict[k][lang];
  const level = (l: "low" | "medium" | "high" | "none") => dict.levels[lang][l];
  return { lang, setLang, t, level };
}
