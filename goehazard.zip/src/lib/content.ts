type L = { id: string; en: string };

export const quiz: { q: L; options: L[]; answer: number; why: L }[] = [
  {
    q: { id: "Apa yang dimaksud dengan e-waste?", en: "What is e-waste?" },
    options: [
      { id: "Sampah makanan", en: "Food waste" },
      { id: "Limbah perangkat elektronik bekas", en: "Discarded electronic devices" },
      { id: "Sampah plastik", en: "Plastic waste" },
      { id: "Limbah cair pabrik", en: "Factory liquid waste" },
    ],
    answer: 1,
    why: { id: "E-waste adalah perangkat listrik/elektronik yang sudah tidak terpakai.", en: "E-waste is unused electrical/electronic equipment." },
  },
  {
    q: { id: "Logam berat apa yang banyak ada di solder papan sirkuit lama?", en: "Which heavy metal is common in old circuit-board solder?" },
    options: [
      { id: "Emas", en: "Gold" },
      { id: "Aluminium", en: "Aluminium" },
      { id: "Timbal", en: "Lead" },
      { id: "Besi", en: "Iron" },
    ],
    answer: 2,
    why: { id: "Timbal dapat merusak saraf dan ginjal.", en: "Lead can damage nerves and kidneys." },
  },
  {
    q: { id: "Lampu neon (TL/CFL) mengandung zat berbahaya apa?", en: "Fluorescent lamps contain which hazardous substance?" },
    options: [
      { id: "Merkuri", en: "Mercury" },
      { id: "Garam", en: "Salt" },
      { id: "Karbon", en: "Carbon" },
      { id: "Silikon", en: "Silicon" },
    ],
    answer: 0,
    why: { id: "Merkuri beracun bila uapnya terhirup.", en: "Mercury vapor is toxic when inhaled." },
  },
  {
    q: { id: "Cara terbaik membuang baterai HP bekas adalah…", en: "Best way to dispose of an old phone battery is…" },
    options: [
      { id: "Dibakar", en: "Burn it" },
      { id: "Dibuang ke tempat sampah biasa", en: "Regular trash bin" },
      { id: "Diserahkan ke titik drop-off e-waste", en: "Hand it to an e-waste drop-off" },
      { id: "Dikubur di tanah", en: "Bury it" },
    ],
    answer: 2,
    why: { id: "Baterai litium bisa terbakar dan mencemari tanah.", en: "Lithium batteries can catch fire and pollute soil." },
  },
  {
    q: { id: "Apa itu urban mining?", en: "What is urban mining?" },
    options: [
      { id: "Menambang batu bara di kota", en: "Coal mining in cities" },
      { id: "Mengambil kembali logam berharga dari e-waste", en: "Recovering valuable metals from e-waste" },
      { id: "Membangun gedung tinggi", en: "Building skyscrapers" },
      { id: "Menanam pohon di kota", en: "Planting trees in cities" },
    ],
    answer: 1,
    why: { id: "1 ton ponsel bekas bisa mengandung emas lebih banyak dari 1 ton bijih emas.", en: "1 tonne of old phones can hold more gold than 1 tonne of gold ore." },
  },
  {
    q: { id: "Kadmium dalam e-waste banyak ditemukan pada…", en: "Cadmium in e-waste is often found in…" },
    options: [
      { id: "Baterai Ni-Cd", en: "Ni-Cd batteries" },
      { id: "Kabel tembaga", en: "Copper cables" },
      { id: "Casing kayu", en: "Wooden casings" },
      { id: "Kertas manual", en: "Paper manuals" },
    ],
    answer: 0,
    why: { id: "Kadmium dapat merusak ginjal dan tulang.", en: "Cadmium can damage kidneys and bones." },
  },
  {
    q: { id: "Peraturan Indonesia tentang pengelolaan limbah B3 adalah…", en: "Indonesia's regulation on hazardous (B3) waste is…" },
    options: [
      { id: "PP No. 22 Tahun 2021", en: "Government Regulation No. 22/2021" },
      { id: "UU Lalu Lintas", en: "Traffic Law" },
      { id: "UU Pajak", en: "Tax Law" },
      { id: "Perda Parkir", en: "Parking bylaw" },
    ],
    answer: 0,
    why: { id: "PP 22/2021 mengatur pengelolaan limbah B3, termasuk e-waste.", en: "PP 22/2021 governs B3 waste, including e-waste." },
  },
  {
    q: { id: "Konvensi internasional yang mengatur perpindahan limbah berbahaya antarnegara?", en: "International treaty controlling cross-border hazardous waste?" },
    options: [
      { id: "Konvensi Basel", en: "Basel Convention" },
      { id: "Protokol Kyoto", en: "Kyoto Protocol" },
      { id: "Piagam PBB", en: "UN Charter" },
      { id: "Konvensi Jenewa", en: "Geneva Convention" },
    ],
    answer: 0,
    why: { id: "Konvensi Basel (1989) membatasi ekspor limbah berbahaya.", en: "The Basel Convention (1989) restricts hazardous waste exports." },
  },
];

export type EduSection = { title: L; points: L[] };
export const eduModules: { emoji: string; title: L; sections: EduSection[] }[] = [
  {
    emoji: "☣️",
    title: { id: "Bahaya Kimia Limbah B3", en: "Hazardous (B3) Chemical Dangers" },
    sections: [
      {
        title: { id: "Merkuri (Hg) — lampu TL/CFL", en: "Mercury (Hg) — fluorescent lamps" },
        points: [
          { id: "Sumber: lampu TL, CFL, layar LCD lama berlampu latar CCFL, termometer.", en: "Source: fluorescent tubes, CFLs, older CCFL-backlit LCDs, thermometers." },
          { id: "Kesehatan: uap merkuri merusak otak, saraf, ginjal, dan janin.", en: "Health: mercury vapour damages the brain, nerves, kidneys and unborn babies." },
          { id: "Lingkungan: berubah menjadi metilmerkuri di air dan menumpuk di ikan.", en: "Environment: turns into methylmercury in water and builds up in fish." },
          { id: "Bila lampu pecah: buka jendela, tinggalkan ruangan 15 menit, jangan disedot vacuum.", en: "If a lamp breaks: open windows, leave the room 15 minutes, never vacuum it." },
        ],
      },
      {
        title: { id: "Timbal (Pb) & Kadmium (Cd) — baterai & PCB", en: "Lead (Pb) & Cadmium (Cd) — batteries & PCBs" },
        points: [
          { id: "Sumber: solder papan sirkuit (PCB), aki, kaca CRT, baterai Ni-Cd.", en: "Source: circuit-board (PCB) solder, car batteries, CRT glass, Ni-Cd batteries." },
          { id: "Timbal: menurunkan IQ anak, merusak saraf, darah, dan ginjal.", en: "Lead: lowers children's IQ, harms nerves, blood and kidneys." },
          { id: "Kadmium: karsinogen, merusak ginjal dan membuat tulang rapuh.", en: "Cadmium: carcinogen, damages kidneys and weakens bones." },
          { id: "Lingkungan: larut ke tanah dan air tanah bila dibuang ke TPA atau dibakar.", en: "Environment: leaches into soil and groundwater when landfilled or burned." },
        ],
      },
      {
        title: { id: "Lithium-ion — baterai smartphone", en: "Lithium-ion — smartphone batteries" },
        points: [
          { id: "Sumber: baterai HP, laptop, power bank, rokok elektrik, sepeda listrik.", en: "Source: phone, laptop, power bank, e-cigarette and e-bike batteries." },
          { id: "Risiko: baterai penyok atau menggembung dapat terbakar dan meledak (thermal runaway).", en: "Risk: dented or swollen batteries can catch fire and explode (thermal runaway)." },
          { id: "Elektrolitnya beracun dan dapat melepaskan gas fluorida saat terbakar.", en: "Its electrolyte is toxic and can release fluoride gases when burning." },
          { id: "Tutup kutub baterai dengan selotip, jangan ditusuk, dan jangan dibuang ke tempat sampah biasa.", en: "Tape the terminals, never puncture it, and never put it in household trash." },
        ],
      },
    ],
  },
  {
    emoji: "⛏️",
    title: { id: "Komponen Urban Mining", en: "Urban Mining Components" },
    sections: [
      {
        title: { id: "Apa itu urban mining?", en: "What is urban mining?" },
        points: [
          { id: "Mengambil kembali logam berharga dari barang elektronik bekas, bukan dari tambang.", en: "Recovering valuable metals from old electronics instead of from mines." },
          { id: "Satu ton HP bekas bisa mengandung emas jauh lebih banyak dibanding satu ton bijih emas.", en: "A tonne of old phones can hold far more gold than a tonne of gold ore." },
        ],
      },
      {
        title: { id: "Logam berharga & letaknya", en: "Precious metals & where they are" },
        points: [
          { id: "Emas (Au): lapisan konektor, pin prosesor, dan jalur PCB karena tahan karat.", en: "Gold (Au): connector plating, CPU pins and PCB traces because it resists corrosion." },
          { id: "Tembaga (Cu): kabel, kumparan motor, dan jalur sirkuit — logam terbanyak di e-waste.", en: "Copper (Cu): cables, motor coils and circuit traces — the most abundant metal in e-waste." },
          { id: "Perak (Ag): pasta solder, saklar, dan panel surya.", en: "Silver (Ag): solder paste, switches and solar panels." },
          { id: "Platinum & Paladium (Pt/Pd): kapasitor keramik dan hard disk.", en: "Platinum & Palladium (Pt/Pd): ceramic capacitors and hard disks." },
        ],
      },
      {
        title: { id: "Cara daur ulang yang benar", en: "Recycling the right way" },
        points: [
          { id: "Logam dipisahkan di fasilitas resmi dengan proses tertutup dan pengolahan limbah.", en: "Metals are separated in licensed facilities with closed processes and waste treatment." },
          { id: "Hindari pembakaran kabel atau perendaman asam di rumah: menghasilkan dioksin dan limbah beracun.", en: "Avoid burning cables or acid baths at home: they create dioxins and toxic waste." },
          { id: "Mendaur ulang mengurangi kebutuhan tambang baru dan menghemat energi.", en: "Recycling reduces the need for new mines and saves energy." },
        ],
      },
    ],
  },
  {
    emoji: "⚖️",
    title: { id: "Regulasi & Penanganan Aman", en: "Regulations & Safe Handling" },
    sections: [
      {
        title: { id: "Aturan yang berlaku", en: "Applicable rules" },
        points: [
          { id: "PP No. 22 Tahun 2021: limbah elektronik termasuk limbah B3 yang wajib dikelola khusus.", en: "Government Regulation 22/2021 (Indonesia): e-waste is hazardous (B3) waste requiring special management." },
          { id: "Permen LHK No. 6 Tahun 2021: tata cara penyimpanan, pengangkutan, dan pengolahan limbah B3.", en: "Minister of Environment Reg. 6/2021: procedures for storing, transporting and treating B3 waste." },
          { id: "UU No. 18 Tahun 2008 tentang Pengelolaan Sampah: sampah spesifik termasuk elektronik.", en: "Law 18/2008 on Waste Management: covers specific waste including electronics." },
          { id: "Konvensi Basel (1989): membatasi ekspor-impor limbah berbahaya antarnegara.", en: "Basel Convention (1989): restricts cross-border movement of hazardous waste." },
        ],
      },
      {
        title: { id: "Standar penanganan di rumah", en: "Handling standards at home" },
        points: [
          { id: "Simpan: tempat kering, sejuk, terpisah dari sampah biasa, jauh dari anak-anak.", en: "Store: dry, cool place, separate from regular trash, away from children." },
          { id: "Kemas: bungkus lampu agar tidak pecah, tutup kutub baterai, keluarkan baterai dari perangkat bila bisa.", en: "Pack: wrap lamps to avoid breakage, tape battery terminals, remove batteries when possible." },
          { id: "Hapus data pribadi dan lakukan reset pabrik sebelum menyerahkan HP/laptop.", en: "Wipe personal data and factory-reset phones/laptops before handing them over." },
          { id: "Serahkan ke dropbox resmi, program take-back merek, atau pengelola berizin.", en: "Hand over to official drop boxes, brand take-back programs or licensed handlers." },
        ],
      },
    ],
  },
  {
    emoji: "💡",
    title: { id: "Fun Facts Seputar E-Waste", en: "E-Waste Fun Facts" },
    sections: [
      {
        title: { id: "Fakta dunia", en: "Global facts" },
        points: [
          { id: "Dunia menghasilkan sekitar 62 juta ton e-waste pada 2022 (Global E-waste Monitor 2024).", en: "The world produced about 62 million tonnes of e-waste in 2022 (Global E-waste Monitor 2024)." },
          { id: "Hanya sekitar 22% yang tercatat didaur ulang dengan benar.", en: "Only about 22% was documented as properly recycled." },
          { id: "Medali Olimpiade Tokyo 2020 dibuat dari logam hasil daur ulang HP dan elektronik bekas.", en: "Tokyo 2020 Olympic medals were made from metals recycled from old phones and electronics." },
        ],
      },
      {
        title: { id: "Fakta sehari-hari", en: "Everyday facts" },
        points: [
          { id: "Indonesia termasuk penghasil e-waste terbesar di Asia Tenggara.", en: "Indonesia is among the largest e-waste producers in Southeast Asia." },
          { id: "Banyak rumah menyimpan HP lama di laci — padahal logamnya bisa dipakai lagi.", en: "Many homes keep old phones in drawers — yet their metals could be reused." },
          { id: "Memperpanjang umur HP 1 tahun saja sudah mengurangi jejak karbonnya secara nyata.", en: "Keeping a phone just one year longer noticeably cuts its carbon footprint." },
        ],
      },
    ],
  },
];
