# Roadmap
- [x] Remix: empty Drizzle migration set for the new database (already clean)
- [x] Clear error message when AI analysis fails (credits/rate limit)
- [x] Drop-off list from OpenStreetMap (no AI, no Google key); tap opens Google Maps
