# e-hazardglobal

**E-Hazard Tracker** — aplikasi web berbasis AI untuk mendeteksi limbah elektronik (e-waste) dan bahan berbahaya & beracun (B3) hanya dengan foto.

Alur utamanya: **foto barang → tahu bahayanya → belajar cara amannya → antar ke drop-off terdekat.**

## Fitur

| Fitur | Cara kerja |
| --- | --- |
| **Deteksi E-Waste** | Ambil foto / pilih dari galeri → AI menampilkan nama barang, tingkat bahaya, kandungan B3, dampak kesehatan, dan langkah penanganan aman. |
| **Cari Drop-off Point** | Ketik nama kota → daftar lokasi penerimaan limbah (data OpenStreetMap, gratis tanpa API key) → tap salah satu untuk membuka rute di Google Maps. |
| **Edukasi B3** | Materi tentang B3, *urban mining*, regulasi, serta fakta & statistik e-waste. |
| **Kuis Interaktif** | Soal dibuat otomatis oleh AI berdasarkan materi Edukasi, jadi selalu baru setiap kali dibuka. |

Dukungan dua bahasa (**ID / EN**) — hasil analisis ikut diterjemahkan otomatis saat bahasa diganti, tanpa perlu memfoto ulang.

## Halaman

1. `/` — Selamat datang (maskot Elzero + tagline + tombol Masuk)
2. `/dashboard` — Menu 4 fitur utama
3. `/hasil` — Hasil analisis foto
4. `/edu` — Materi edukasi B3
5. `/quiz` — Kuis dinamis

## Teknologi

- **React 19 + TanStack Start** (routing, SSR, server functions)
- **Tailwind CSS v4** untuk styling
- **Lovable AI Gateway** (`openai/gpt-6-astra`) untuk analisis foto, penerjemahan hasil, dan pembuatan soal kuis
- **OpenStreetMap** (Nominatim + Overpass) untuk data titik drop-off
- **Lovable Cloud** untuk backend

## Struktur penting

```text
src/
  routes/          # 5 halaman aplikasi
  lib/
    ai.functions.ts  # server function: analyzeImage, translateResult, findDropoff, generateQuiz
    i18n.tsx         # kamus bahasa ID/EN
    content.ts       # materi edukasi & bank soal cadangan
    scan-store.ts    # penyimpanan hasil analisis
  components/      # ScanButton, DropoffSearch, Mascot, AppShell, LangToggle
  assets/          # gambar maskot & latar
```

## Pengembangan lokal

Butuh Node.js dan npm — [install dengan nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone https://github.com/hazardglobal9-ctrl/e-hazardglobal.git
cd e-hazardglobal
npm i
npm run dev
```

Aplikasi terbuka di `http://localhost:8080`.

## Build with Lovable

Proyek ini dibuat dan dikembangkan dengan [Lovable](https://lovable.dev).

- **Ship faster**: cukup jelaskan yang ingin dibuat, Lovable menulis kodenya.
- **Stay in sync**: setiap perubahan di Lovable tercatat sebagai commit di repository ini.
- **Full ownership**: kode ini milik Anda — push ke `main` dan perubahannya tersinkron kembali ke Lovable.

## Catatan

- Analisis foto dan kuis AI membutuhkan kredit AI pada akun Lovable. Jika kredit habis, aplikasi menampilkan pesan error yang jelas alih-alih gagal diam-diam.
- Daftar drop-off memakai data terbuka OpenStreetMap; bila servernya sedang padat, aplikasi menampilkan daftar kategori pencarian Google Maps sebagai cadangan.
- Gambar maskot Elzero dipakai apa adanya dari artwork asli (hanya latar hitamnya dihapus), bentuknya tidak diubah.
