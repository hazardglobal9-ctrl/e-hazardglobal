<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- AI calls (photo analysis, drop-off search) live in `src/lib/ai.functions.ts` as server functions with structured output, so the API key stays server-side.
- UI text goes through the `useLang()` dictionary in `src/lib/i18n.tsx`; every visible string needs both ID and EN.
- Mascot images are cut from the user's original artwork (background removed only); never redraw or regenerate them with AI.
- Drop-off search uses free OpenStreetMap data (Nominatim + Overpass mirrors, 14s timeout) with a fixed list of Google Maps search categories as fallback — no AI credits or Google key needed.
