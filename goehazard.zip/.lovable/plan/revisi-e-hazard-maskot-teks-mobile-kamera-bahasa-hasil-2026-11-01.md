# Revisi E-Hazard — Maskot, Teks Mobile, Kamera, Bahasa Hasil

## 1. Maskot Halaman 1 lebih pas

- Maskot sedikit dikecilkan (sekitar 20%) dan diberi ruang agar tidak terpotong saat bergerak naik-turun.
- Ukuran menyesuaikan tinggi layar HP, jadi sapaan, tagline, dan tombol "Masuk" tetap muat dalam satu layar.

## 2. Tulisan tidak terpecah di HP

- Ukuran judul dan teks disesuaikan untuk layar kecil (sekitar 360–400 px).
- Baris dibagi seimbang supaya tidak ada satu kata yang tertinggal sendirian di baris baru.
- Frasa penting (mis. "Sahabat Elzero", "1 scan", "E-Hazard") dijaga tetap dalam satu baris.
- Dicek di semua halaman: Selamat Datang, Dashboard, Hasil, Quiz, Edu, dalam ID dan EN.

## 3. Kamera bawaan HP

- Saat menekan "Klik untuk mendeteksi", muncul dua pilihan:
  - "Ambil Foto" — langsung membuka kamera bawaan HP (Android & iPhone).
  - "Pilih dari Galeri" — mengunggah foto yang sudah ada.
- Berlaku juga untuk tombol "Deteksi Ulang" di halaman Hasil.

## 4. Bahasa hasil analisis ikut berganti

- AI menganalisis dalam satu bahasa yang sedang dipilih. Saat bahasa diganti, hasil yang sama diterjemahkan otomatis (tanpa memindai foto ulang), lalu disimpan agar ganti bolak-balik langsung tampil.
- Tombol bahasa langsung mengganti seluruh hasil (nama benda, kategori, deskripsi, kandungan, langkah) tanpa perlu memindai ulang.

## **5. background konsistensi**

- pada saat membuka dimobile/handphone background kadang bergeser dan tidak permanen di tempat nya dan juga sesuaikan lah dengan desain pdf yang saya berikan kemarin untuk di jadikan acuan membuat desain aplikasi.

## Detail Teknis

- Mascot: kurangi lebar (`w-48 sm:w-56`, batasi `max-h-[35vh]`), beri padding vertikal untuk animasi `float-slow`, pastikan tidak ada `overflow-hidden` pada pembungkusnya.
- Teks: `text-balance`/`text-pretty` pada judul dan paragraf, ukuran responsif (`text-3xl sm:text-4xl`), `whitespace-nowrap` untuk frasa kunci lewat span di kamus i18n.
- ScanButton: dua `<input type="file" accept="image/*">`, satu dengan `capture="environment"`; tampilkan pilihan dalam sheet/dialog kecil.
- `ai.functions.ts`: tambah server function `translateResult` (teks hasil saja, tanpa gambar); `scan-store` menyimpan hasil per bahasa, `hasil.tsx` memanggil terjemahan bila bahasa aktif belum ada.