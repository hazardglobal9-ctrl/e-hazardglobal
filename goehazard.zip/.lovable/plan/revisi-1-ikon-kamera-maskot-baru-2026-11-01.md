# Revisi: 1 Ikon Kamera & Maskot Baru

## 1. Satu ikon kamera di "Deteksi E-Waste"

- Dua tombol ("Ambil Foto" & "Pilih dari Galeri") diganti menjadi **satu ikon kamera besar** yang bersih seperti awal gambar di pdf desain aplikasi.
- Saat diklik, HP otomatis menampilkan menu bawaan: **Kamera** atau **Galeri/File** (Android & iPhone). Jadi HP yang biasanya hanya membuka unggahan tetap bisa memotret, dan yang ingin unggah tetap bisa.
- Tombol "Deteksi Ulang" di halaman Hasil dibuat sama (satu tombol).

## 2. Ganti maskot yang terpotong

- Maskot pegang pemindai (halaman Selamat Datang) dan juga gambar yang digunakan untuk menunggu hasil analisis diganti dengan gambar baru yang utuh dari foto yang Anda kirim.
- Hanya latar hitam yang dihapus; bentuk, warna, dan garis maskot tidak diubah sama sekali (tidak digambar ulang AI).
- Cahaya hijau hologram tetap dijaga.
- tetap bergerak keatas kebawah seperti biasa.

## Detail Teknis

- `ScanButton.tsx`: satu `<input type="file" accept="image/*">` tanpa atribut `capture` — tanpa `capture` browser HP menampilkan pilihan kamera + galeri; dengan `capture` sebagian HP memaksa kamera/unggah saja. Hapus kunci i18n yang tak terpakai, tambah label ikon (ID/EN).
- `hasil.tsx`: tombol "Deteksi Ulang" memakai input yang sama.
- Maskot: hapus latar hitam via PIL (komponen gelap yang terhubung ke tepi gambar saja, agar garis hitam & layar wajah tetap), unggah sebagai aset baru `mascot-a`, perbarui pointer.