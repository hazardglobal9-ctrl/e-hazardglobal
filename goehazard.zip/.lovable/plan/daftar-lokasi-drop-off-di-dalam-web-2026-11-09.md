# Daftar Lokasi Drop-off di Dalam Web

## Yang akan terjadi
- Pengguna mengetik nama kota lalu menekan "Cari".
- Daftar tempat drop-off e-waste muncul langsung di halaman (tanpa membuka Google Maps dulu). Tiap kartu berisi:
  - Nama tempat
  - Alamat
  - Rating bintang (jika ada) dan status "Buka/Tutup sekarang"
- Google Maps baru terbuka saat salah satu kartu ditekan, langsung ke titik tempat itu.
- Jika tidak ada hasil, muncul pesan ramah dan tautan "Cari langsung di Google Maps".
- Semua teks tetap ID/EN.

## Kenapa diganti
Daftar sekarang ditebak oleh AI, jadi lambat (10–15 detik) dan kadang tempatnya tidak ada atau kosong. Daftar baru diambil dari data asli Google Maps, sehingga lebih cepat (sekitar 1–2 detik) dan tempatnya nyata.

## Yang perlu Anda lakukan
- Menyetujui sambungan Google Maps (kartu akan muncul di chat, pilih "Managed by Lovable" sehingga tidak perlu kunci sendiri).
- Catatan biaya: setiap pencarian memakai kuota Google Maps. Satu pencarian hanya mengambil maksimal 10 tempat dan pencarian kota yang sama disimpan sementara agar hemat.

## Detail Teknis
- Sambungkan connector `google_maps` (managed).
- Ganti `findDropoff` di `src/lib/ai.functions.ts` menjadi pemanggilan Places API (New) `places:searchText` lewat gateway, `textQuery: "e-waste recycling drop off {city}"`, `pageSize` 10, field mask `places.id,displayName,formattedAddress,rating,currentOpeningHours.openNow,googleMapsUri`, `languageCode` sesuai bahasa. Input kota divalidasi (maks. 80 karakter), cache di memori per kota+bahasa, cabang error 403 yang jelas.
- `DropoffSearch.tsx`: kartu list menampilkan nama, alamat, rating, buka/tutup; link ke `googleMapsUri` (fallback ke URL pencarian).
- Tambah kunci i18n `openNow` / `closedNow`.
