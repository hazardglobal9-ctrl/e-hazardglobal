# Revisi E-Hazard — Gabungan Daftar Kesalahan + Desain Baru

## 1. Latar belakang baru (dari desain PDF)

- Semua halaman memakai ilustrasi langit biru berawan + jalan kota dengan pohon dari file desain Anda (diambil dari halaman 3 PDF, tidak digambar ulang).
- Gambar latar menempel penuh di layar, isi halaman tetap di atasnya.

## 2. Maskot tidak terpotong

- Maskot tampil utuh di semua ukuran layar HP: ukurannya menyesuaikan proporsi aslinya, tidak dipotong, dengan ruang yang lentur di sekelilingnya.

## 3. Halaman Selamat Datang (sesuai PDF hal. 2)

- Tombol bahasa oranye kecil di pojok kanan atas.
- Maskot pose pemindai di atas.
- Judul besar oranye bergaris putih: "Halo, Sahabat Elzero" (EN: "Hello, Elzero Friends").
- Sub-teks: "Selamat datang di E-Hazard, asisten pintar pendeteksi limbah elektronik".
- Kotak oranye bergradasi berisi tagline "Teknologi di tanganmu, Informasi dalam 1 scan".
- Tombol oranye tua "Masuk" dengan tulisan besar.

## 4. Dashboard (sesuai PDF hal. 1)

- Judul tengah atas oranye: "Hai!, mau cek limbah apa hari ini?" + tombol bahasa kecil di pojok kanan atas.
- Dua kotak oranye-peach bergradasi (Quiz kiri, Edu kanan), maskot pose tablet di tengah.
- Panel oranye tua berisi kolom pencarian krem dengan ikon kaca pembesar dan tombol "search".
- Kartu "Detect E-Waste" bergradasi cokelat-peach, di dalamnya kotak krem dengan ikon kamera oranye dan tulisan "Click to detect".
- Teks kamera diubah menjadi: "Foto barangmu, Elzero akan menganalisis tingkat bahayanya." (EN: "Snap your item and Elzero will analyze its hazard level.")

## 5. Pencarian drop-off langsung ke Google Maps

- Saat menekan "search", aplikasi langsung membuka Google Maps dengan pencarian "e-waste drop off [nama kota]" — berlaku untuk kota mana pun di dunia.
- Daftar saran tempat dari AI dihapus agar sesuai dokumen (lebih cepat dan pasti nyata).

## 6. Halaman Hasil Analisis (sesuai PDF hal. 3)

- Judul oranye "Hasil analisis:" di kiri atas dengan latar ilustrasi; kartu hasil (status, bar bahaya, deskripsi, kandungan, langkah) dibuat semi-transparan agar latar tetap terlihat. Desain aplikasi untuk hasil analisis tata letak tetap menyesuaikan dengan aplikasi sebelumnya. yang berubah background dan tulisan hasil analisis yang memjadi sub bab.

## 7. Materi Edu diperdalam — 3 kategori

1. Bahaya Kimia Limbah B3: Merkuri (lampu TL), Timbal & Kadmium (baterai/PCB), Lithium-ion (baterai HP) — sumber, dampak kesehatan, dampak lingkungan.
2. Komponen Urban Mining: Emas, Tembaga, Perak, Platinum di sirkuit bekas — letaknya, nilai, cara daur ulang yang benar.
3. Regulasi & Penanganan Aman: PP 22/2021, Permen LHK terkait B3, Konvensi Basel, serta standar penyimpanan, pengemasan, dan penyerahan ke pengelola resmi.
4. *Fun Facts* Seputar Limbah Elektronik (*E-Waste*)
  Tiap kategori bisa dibuka-tutup dan berisi beberapa sub-bagian.

## 8. Bahasa konsisten

- Semua teks di halaman 1, 2, 3 (dan Quiz/Edu) dicek ulang; teks yang belum ikut berganti (judul, tombol, pesan error, tulisan maskot) dimasukkan ke kamus ID/EN pusat, sehingga satu tombol bahasa mengganti semuanya sekaligus.

## 9. Huruf modern

- Ganti ke "Plus Jakarta Sans" untuk teks, dan huruf membulat tebal (Fredoka) untuk judul seperti di desain, dengan ketebalan dan ukuran yang ditata ulang (sapaan, persentase bahaya, deskripsi).

## Catatan

- Isi materi Edu yang diperluas oleh kamu; mohon diperiksa dengan baik.

## Detail Teknis

- Latar: unggah `page_3.jpg` dari PDF lewat lovable-assets, dipasang sebagai `background-image` fixed `cover` di `__root`.
- Mascot: wrapper `flex justify-center max-w-full`, img `object-contain h-auto max-w-full`, hapus overflow hidden.
- `DropoffSearch`: `window.open("https://www.google.com/maps/search/" + encodeURIComponent("e-waste drop off " + city))`; hapus `findDropoff` dari `ai.functions.ts`.
- i18n tetap lewat `useLang()` (React, bukan data-lang-key DOM — hasilnya sama: real-time serentak); audit semua string hardcode termasuk error di `ai.functions.ts` dan alt maskot.
- Font via `<link>` Google Fonts di `__root.tsx`, token `--font-sans`/`--font-display` di `styles.css`; judul pakai text-stroke/shadow putih.
- `content.ts`: struktur `eduModules` menjadi 3 modul dengan `sections[]` bilingual.