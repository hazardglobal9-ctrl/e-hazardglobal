# E-Hazard Tracker — Rencana Aplikasi

Aplikasi web yang ramah di HP untuk mengenali limbah elektronik (e-waste) lewat foto, memakai Lovable AI. Ada maskot robot, dua bahasa (ID/EN), kuis, materi edukasi, dan pencarian lokasi pembuangan.

## Tampilan

- Warna sesuai dokumen: latar Cream #FDF8E2, teks Violet Gelap #504E76, kartu Violet Pastel #C4C3E3, tombol utama & bahaya Oranye #F1642E, edukasi/aman Hijau Zaitun #A3B565, kuis/highlight Kuning Pastel #FCDD9D.
- Gaya minimalis dan bersih, huruf yang ramah dan membulat.
- Tombol bahasa kecil 🇮🇩 / 🇬🇧 di pojok kanan atas setiap halaman. Seluruh teks langsung berganti bahasa, dan hasil analisis AI juga mengikuti bahasa yang dipilih.

## Maskot (pakai gambar asli, bentuknya tidak diubah)

- Gambar yang Anda kirim dipotong menjadi 2 pose. Saya hanya menghapus latar hitamnya agar menyatu dengan latar krem. Bentuk, warna, dan detailnya tidak diubah atau digambar ulang.
  - Pose A (memegang pemindai hologram): di Halaman 1, di atas teks sapaan dan tagline.
  - Pose B (memegang tablet dan menunjuk): di Halaman 2, di tengah antara tombol Quiz dan Edu.
- Pose A juga muncul kecil di Halaman 3 saat foto sedang dianalisis.

## Halaman

**1. Selamat Datang (/)**

- Sapaan hangat, nama "E-Hazard", dan tagline "Teknologi di tanganmu, Informasi dalam 1 scan".
- Maskot di atas kata sapaan dan tagline, dan satu tombol oranye "Masuk" menuju Dashboard.

**2. Dashboard (/dashboard)**

- Atas: sapaan di tengah atas, tombol bahasa kecil di pojok kanan atas (fitur tambahan).
- Baris fitur: tombol Quiz (kuning), Maskot di tengah, tombol Edu (hijau).
- Kolom pencarian drop-off: pengguna mengetik nama kota mana pun di dunia. AI menyarankan beberapa jenis atau nama tempat pembuangan e-waste, dan setiap hasil punya tombol "Buka di Google Maps" untuk melihat titik terdekat yang nyata.
- Area kamera besar berwarna oranye dengan tombol "Klik untuk Mendeteksi". Di HP tombol ini membuka kamera serta unggah foto, di laptop membuka pilihan unggah foto.

**3. Hasil Analisis (/hasil)**

- Status: termasuk e-waste atau tidak, beserta kategorinya. Contoh: manusia → bukan e-waste, laptop → e-waste kategori IT & telekomunikasi.
- Indikator bahaya: label Rendah/Sedang/Tinggi dengan persentase (misalnya 85%) dalam bentuk bar berwarna. Kuning untuk rendah/sedang, oranye untuk tinggi, hijau jika aman.
- Penjelasan singkat tentang perangkat.
- Kandungan berbahaya, misalnya Timbal, Merkuri, Kadmium, dan Litium, masing-masing dengan efeknya.
- Cara penanganan dan solusi dalam bentuk langkah-langkah.
- Menu pintas di bawah: Deteksi Ulang, Quiz, Edu, dan Cari Drop-off.

**4. Quiz (/quiz)**

- 8 soal pilihan ganda tentang e-waste dalam dua bahasa, dengan skor di akhir dan tombol ulangi.

**5. Edu (/edu)**

- 4 modul: Bahaya Kimia, Urban Mining, Fakta Unik E-waste, dan Regulasi Hukum (misalnya PP 22/2021 dan Konvensi Basel).

## Catatan

- Isi soal kuis dan materi edukasi akan saya tulis sendiri sebagai contoh awal, jadi tolong diperiksa nanti.
- Belum ada login atau penyimpanan riwayat. Bisa ditambahkan nanti jika diperlukan.

## Detail Teknis

- Rute TanStack: `/`, `/dashboard`, `/hasil`, `/quiz`, `/edu`. Foto dan hasil analisis dibagikan antarhalaman lewat state di sisi browser.
- Analisis foto: `createServerFn` → Lovable AI Gateway (`openai/gpt-6-astra`, Responses API, input gambar). Output berupa JSON terstruktur dengan isi `is_ewaste`, `category`, `hazard_level`, `hazard_percent`, `description`, `hazardous_materials[]`, `handling_steps[]` sesuai bahasa yang dipilih. Pencarian drop-off memakai pola yang sama.
- Kebutuhan: `LOVABLE_API_KEY`, dan Lovable Cloud diaktifkan hanya untuk menjalankan fungsi server.
- Maskot: dipotong dari gambar unggahan, latar hitam dibuat transparan dengan pemrosesan piksel (bukan digambar ulang oleh AI), lalu disimpan sebagai aset.
- Teks dua bahasa disimpan dalam kamus sederhana dan dikelola dengan language context.