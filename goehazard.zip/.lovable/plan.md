# Perbaikan Analisis Foto + Daftar Lokasi Drop-off

## Penyebab analisis gagal (sudah dicek dari catatan server)
Setiap kali foto dianalisis, server menjawab **"Kredit AI habis"**. Kodenya sudah benar; saldo AI di workspace yang kosong. Tanpa saldo AI, analisis foto, kuis AI, dan daftar drop-off dari AI tidak bisa berjalan.

**Yang perlu Anda lakukan:** isi ulang kredit AI di pengaturan workspace (Settings → Plans & Credits). Setelah diisi, analisis langsung berjalan lagi tanpa perlu mengubah apa pun.

## Perbaikan di aplikasi
1. **Pesan error yang jelas.** Sekarang hanya muncul tulisan "gagal". Nanti muncul pesan yang menjelaskan masalahnya, misalnya "Layanan AI sedang tidak tersedia (kredit habis). Coba lagi nanti." Pesannya tersedia dalam ID dan EN.
2. **Daftar drop-off tanpa AI dan tanpa Google Maps berbayar.** Lokasi diambil dari OpenStreetMap, peta dunia terbuka yang gratis dan tidak perlu izin admin:
   - Ketik nama kota → tekan Cari → muncul daftar tempat daur ulang elektronik/e-waste yang nyata (nama, alamat, jarak dari pusat kota).
   - Google Maps baru terbuka saat salah satu tempat ditekan.
   - Kalau kotanya tidak punya data, muncul pesan dan tombol "Cari langsung di Google Maps".
   - Cara ini tetap jalan walaupun kredit AI habis, dan biasanya hasilnya keluar dalam 1–3 detik.

## Catatan
Data OpenStreetMap diisi oleh komunitas, jadi kota kecil bisa punya lebih sedikit tempat dibanding Google Maps.

## Detail Teknis
- `ai.functions.ts`: deteksi error 402 dan 429 (termasuk yang terbungkus `AI_NoOutputGeneratedError`) → kirim kode `credits`/`rate`/`generic` ke klien; hasil.tsx/ScanButton menampilkan pesan dari i18n.
- `findDropoff` diganti: server function geocode kota lewat Nominatim, lalu memanggil Overpass API (radius 25 km) untuk `recycling:electrical_items=yes`, `recycling:batteries=yes`, `recycling:mobile_phones=yes`, `recycling:small_appliances=yes` (amenity=recycling / shop) dengan batas 15 hasil, diurutkan berdasarkan jarak, dan User-Agent yang valid. Hasil di-cache di memori per kota.
- Link kartu: `https://www.google.com/maps/search/?api=1&query=lat,lng`.
- i18n: `errCredits`, `errRate`, `distanceKm`.
